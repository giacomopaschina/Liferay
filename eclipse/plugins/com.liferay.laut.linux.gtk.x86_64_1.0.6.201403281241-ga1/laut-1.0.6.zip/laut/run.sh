#!/usr/bin/env sh

node/bin/node data/bin/laut.js "$@"